var express = require('express');
var router = express.Router();
var MsSql = require('mssql');

var sqlConfig = {
    user: process.env.DB_TALK_USER,                                                                              
    password: process.env.DB_TALK_PASSWORD,
    server: process.env.DB_HOST,
    port: process.env.SERVER_PORT,
    database: process.env.DB_TALK_NAME
};

router.post('/write_review', function(req, res, next){
    //res.render('member/profile');
    var strSQL = "select MAX(board_id) from " + process.env.DB_TALK_NAME + ".dbo.htBoard";
    MsSql.connect(sqlConfig, function(err) {
    var request = new MsSql.Request();
    request.query(strSQL, (err, row) => {
        
    });

});

module.exports = router;